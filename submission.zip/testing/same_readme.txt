I really liked Moneyball.
I like "Moneyball".
I was completely amazed at how "Rush Hour" was pretty much the most ridiculous thing I've seen in my entire life. 
I hate "Rush Hour".
Rush Hour 2
I like love "Copycat"
I like love "Titanic (1997)"
I like love "Easy A"
yes
:quit 